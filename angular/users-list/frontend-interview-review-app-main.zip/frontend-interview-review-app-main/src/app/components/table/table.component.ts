import { Component } from '@angular/core';
import { ApiService } from '../../services/api.service';
import { Store } from '@ngrx/store';
import { loadUsers, sortUsers } from '../../actions/users.actions';
import {
  getSortColumn,
  getSortDirection,
  getUsers,
} from '../../selectors/users.selectors';


@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent {
  users;
  sortColumn: string;
  sortDirection: string;

  constructor(private api: ApiService, private store: Store) {
    this.api.getData().subscribe(users => {
      this.store.dispatch(loadUsers({ users }));
    });

    this.store.select(getUsers).subscribe(users => {
      this.users = users;
    });

    this.store.select(getSortColumn).subscribe(sortColumn => {
      this.sortColumn = sortColumn;
    });

    this.store.select(getSortDirection).subscribe(sortDirection => {
      this.sortDirection = sortDirection === 'asc' ? '⬆️' : '⬇️';
    });
  }

  sortUsers(column: string): void {
    this.store.dispatch(sortUsers({ column }));
  }
}
