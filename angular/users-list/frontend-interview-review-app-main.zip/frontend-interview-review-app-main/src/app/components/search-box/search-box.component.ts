import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { searchUsers } from '../../actions/users.actions';

@Component({
  selector: 'app-search-box',
  templateUrl: './search-box.component.html',
  styleUrls: ['./search-box.component.scss'],
})
export class SearchBoxComponent implements OnInit {
  private timeout;

  constructor(private store: Store) {}

  ngOnInit(): void {}

  applySearchText(event: any): void {
    if (this.timeout) {
      clearInterval(this.timeout);
    }
    this.timeout = setTimeout(() => {
      this.store.dispatch(searchUsers({ query: event.target.value }));
    }, 500);
  }
}
