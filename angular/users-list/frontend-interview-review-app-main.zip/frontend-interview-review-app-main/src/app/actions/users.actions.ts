import { createAction, props } from '@ngrx/store';

export const loadUsers = createAction(
  '[Users] Load Users',
  props<{users: any[]}>()
);

export const searchUsers = createAction(
  '[Users] Search',
  props<{ query: string }>()
);

export const sortUsers = createAction(
  '[Users] Sort',
  props<{ column: string }>()
);
