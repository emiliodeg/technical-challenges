# FrontendInterviewReviewApp

## Getting started

```
npm install
npm start
```

## Goals

Review the code and make suggestions on how to improve by:

- using best practises
- fix performance issues
- improve typings
- solve any bugs

We're not looking for purely stylistic things like whitespace etc that can be solved automatically by prettier.
